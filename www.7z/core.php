
<?PHP

ob_start();
session_start();
function loggedin()
{
if (isset($_COOKIE['CustID']) && !empty($_COOKIE['CustID']))
{
   $COOKIE = $_COOKIE['CustID'];
$query = "SELECT `ID` FROM `JoinRoom` WHERE `CustID` = '$COOKIE'";
 $conn = new mysqli("localhost", "admin", "admin", "Messapp");
$result = mysqli_query($conn,$query);

if ($result)
{
$query_num = mysqli_num_rows($result);

if ($query_num >= 1)
{

return true;
}
else
{
    return false;
}}}}
?>



