

<?php



if (loggedin())
{
$UserID = $_SESSION['id'];
$query = "SELECT `Room_Name` FROM `mess_room` WHERE `ID` = '$UserID'";

 
$result = mysqli_query($conn,$query);

if ($result)
{
$query_num = mysqli_num_rows($result);

if ($query_num == 1)
{ 
$username = mysqli_fetch_assoc($result)['Room_Name'];
print "<p align=\"RIGHT\" ><span class='sgreen'>Welcome to " . $username;

}}

}

else
{
header('location: ../');
}
?>