<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>MessApp</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/normalize.min.css">
 <script src='../js/jquery-3.2.0.min.js'></script>

    <script src="../js/index.js"></script>
  
      <link rel="stylesheet" href="../css/style.css">

  
</head>

<body>
  
  <div class="mobile">
	<div class="mainContainer">
		<header>
            <a href='../'><i href="../" class="left"></i> </a>
            <a href="../help" class="logo">MessApp</a> 
			<a href="#" class="menuBtn">
				<span class="lines"></span>
			</a>
			<nav class="mainMenu">
				<ul>
					<li>
						<a href="#"></a>
					</li>
					<li>
						<a href="../index.php">Home</a>
					</li>
					<li>
						<a href="../statement">Statement</a>
					</li>
					<li>
						<a href="../member">Members</a>
					</li>
          <li>
						<a href="../about" >About</a>
					</li>
          <li>
						<a href="../help" >Help</a>
					</li>
					<li>
						<a href="../logout.php" class="suBtn">Logout</a>
					</li>
				</ul>
			</nav>
		</header>
		<div class="container">
  
<span class ="sred"> comming soon</span>

		<footer>
           

		</footer>
	</div>
        </div></div>
 

</body> 
</html>
