<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>MessApp</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/normalize.min.css">
 <script src='../js/jquery-3.2.0.min.js'></script>
<script src="../js/jquery-ui-1.10.3.custom.min.js"></script>
    <script src="../js/index.js"></script>
  
      <link rel="stylesheet" href="../css/style.css">

  
</head>

<body>
  <div class="mobile">
	<div class="mainContainer">
		<header>
            <a href='../'><i href="../" class="left"></i> </a>
           <a href="members.php" class="logo">MessApp</a> 
			
		</header>
		<div class="container">
            <center>
                <div class="login">
  <SCRIPT LANGUAGE="JavaScript" src="../js/jquery.js"></SCRIPT>
 <SCRIPT LANGUAGE="JavaScript" src="../js/script.js"></SCRIPT>   
    
     <?php
include("../connect.php");
require '../core.php';
include("../SessionLogged.php");
                    
if (loggedin())
{
    header('location: requestsent.php');
}  

                    
if (isset($_COOKIE['CustID']) && !empty($_COOKIE['CustID']))
{
   $CustID = $_COOKIE['CustID'];
   include("../room.php");


if ($Room == 0 )
{
header('location: ../signup/Selectmethod.php');   
}
}



if (isset($_COOKIE['CustID']) && !empty($_COOKIE['CustID']))
{
   $CustID = $_COOKIE['CustID'];
   $Room = $_COOKIE['Room'];


if ($Room == 0 )
{
header('location: ../signup/Selectmethod.php');
}
else
{
// header('location: ../session/');
}}else
            {
              header('location: ../index.php'); 
            }            
                    

                    
if (isset($_POST['BtnCancel']))

{
    
    
    header('location: ../session');
    
    
}
                    
                    



// join request start



$query = "SELECT `ID`,`CustID`, `JoinDate` FROM `joinroom` WHERE `RoomID`= '$Room'";
echo "<form  Method='POST'>" ;

$result = mysqli_query($conn,$query);
if ($result)
{

if ($result->num_rows > 0)
{
echo "<div class='login'><h1>Join Requests</h1><table>";
$no = "1";
while($row = $result ->fetch_assoc())
{
  
$PNquery = "SELECT `Name` FROM `members` WHERE `ID` = '$row[CustID]'";

 
$PNresult = mysqli_query($conn,$PNquery);

if ($PNresult)
{
$PNrows = mysqli_num_rows($PNresult);
if ($PNrows == 1)
{ 
$PNName = mysqli_fetch_assoc($PNresult)['Name'];

}
else{
  echo "name fetch error";
}
}
$NJoinDate = $row['JoinDate'];
$JoinID = $row['ID'];
echo "<tr><td width='60%'>$PNName</td><td width='20%'><button class='request' name='accept'value='$JoinID' value='Accept'>Accept</button></td><td width='20%'><button class='request' name='decline' value='$JoinID'>Decline</button></td></tr>";

}
echo "</table></div></form>";
}}


if (isset($_POST["accept"]))
{
  $AcceptedID = $_POST['accept'];
   
   $BringAccepter = "SELECT `CustID`, `RoomID`, `JoinDate` FROM `joinroom` WHERE `ID` = '$AcceptedID'";

 
$Bringresult = mysqli_query($conn,$BringAccepter);

if ($Bringresult)
{

    while($Brrows = $Bringresult ->fetch_assoc())
    {
$BringCustID = $Brrows['CustID'];
$BringRoomID = $Brrows['RoomID'];
$BringJoingDate = $Brrows['JoinDate'];
}}
else{
            echo "name fetch error";
}





    $AcceptUpdateQuery = "UPDATE `Members` SET `Room`='$BringRoomID' WHERE ID = '$BringCustID'";

if (mysqli_query($conn, $AcceptUpdateQuery)) {

    $AcceptInsertQuery = "INSERT INTO `datetable`(`CustID`, `RoomID`, `RoomJoined`) VALUES ('$BringCustID','$BringRoomID', '$BringJoingDate')";

if (mysqli_query($conn, $AcceptInsertQuery)) {



$AcceptDeleteQuery = "DELETE FROM `joinroom` WHERE `ID`= '$AcceptedID'";
if (mysqli_query($conn, $AcceptDeleteQuery)) {
    header ("Refresh:0");
}

    echo '<span class="sred">Conguradulations!!.. You are Seccessfully Added... </span>';
        
}
}


    }

    if (isset($_POST["decline"]))
{
  $id = $_POST['decline'];

    $DeclineQuery = "DELETE FROM `joinroom` WHERE `ID` = $id";

if (mysqli_query($conn, $DeclineQuery)) {

    header("Refresh:0");
        
}



    
    }


// Join request end


// add new member start
echo "<div class='login'>
                        <h1>Add New Member</h1>";
if (isset($_POST['addmember']))
{
    $NUsername = $_POST['MemberName'];
    $CKAddquery = "SELECT `ID`, `Room` FROM `members` WHERE `UserName` = '$NUsername'";

 
    $CKAddresult = mysqli_query($conn,$CKAddquery);

    if ($CKAddresult)
    {
        $CKAddrows = mysqli_num_rows($CKAddresult);
        if ($CKAddrows == 1)
        { 
            while($CKAddrows = $CKAddresult ->fetch_assoc())
                {
                $BringACustID = $CKAddrows['ID'];
                $CKAddRoom = $CKAddrows['Room'];
                }
            if ($CKAddRoom > 0)
                {
                echo "<span class='sred'>This Member Already member in other room</span>";
                } else 
                {


                    $AcceptUpdateQuery = "UPDATE `Members` SET `Room`='$Room' WHERE ID = '$BringACustID'";

                    if (mysqli_query($conn, $AcceptUpdateQuery)) 
                    {
                        $AdderDate = $_POST['joindate'];
                        $AcceptInsertQuery = "INSERT INTO `datetable`(`CustID`, `RoomID`, `RoomJoined`) VALUES ('$BringACustID','$Room', '$AdderDate')";

                        if (mysqli_query($conn, $AcceptInsertQuery))
                            {
                            echo "<span class='sred'>Conguradulations!!.. You are Seccessfully Added Mr. $NUsername to this room </span>";
            
                            }   
                    }
                
                }
            }
            else
            {
                echo "<span class='sred'> Wrong Member Name</span>";
            }
    } else 
        { 
             echo "Query Error 0383732";
        }
}

// add new member end

  ?>
   
                <br>

                     
                        
<form method="Post">
                        <div id="holder"> 
            Select Member<br>
                        <input type="text" id="keyword" tabindex="0" name="MemberName" autocomplete='off' >
		                </div>
		                 <div id="ajax_response"></div>
	                     <img src="../images/loading.gif" id="loading">
                         Join Date<br>
                          <?php $date = date("Y-m-01"); 
                          
                            echo "<input type='date' value='$date' name='joindate'>";   
                            ?>

                        <button class="btn"  name="addmember" id ="addmember"> add this member</button>

</form>
                    </div><br>
                    
                    
               
<?php   
         
echo "<div class='login'> <h1>Room Members</h1>";
$RoomMembersQuery = "SELECT MIN(`datetable`.`RoomJoined`) as dates, members.Name, members.ID FROM `datetable`,members WHERE members.Room = $Room AND datetable.CustID = members.ID GROUP BY members.ID";

$Membersresult = mysqli_query($conn,$RoomMembersQuery);

if ($Membersresult)
{

echo "<table><th>Joint Date</th><th>Name</th><th>Edit</th>";
while($Mrow = $Membersresult ->fetch_assoc())
{
$MemberName = $Mrow['Name'];
$Joined = $Mrow['dates'];
$membID = $Mrow['ID'];
echo "<tr><td> $Joined</td><td>$MemberName</td>
    <td>
    <div name = 'status'><span id='spnStatus' class='sgreen' onclick='spnEditStatus()'>Available</span></div>
    <div name = 'EdtStatus' style='display:none'><INPUT TYPE='radio' name='rdVecation'VALUE='1' >his on vection<INPUT TYPE='radio' name='rdVecation'VALUE='2' >Remove him <br><input type=submit name='btn$membID' value='save'></div>

    </td>

</tr>";

}

}

 echo "</table></div>";             
    
 
?>

               
                
 

</div></center>
         
		

            
            





		<footer>
            
		</footer>
	</div>
</div>
 
 <script>


function spnEditStatus()
{
  alert ("editCode");
    document.getElementbyName('edtStatus').style.display='block' ;
}
</script>

</body> 
</html>
