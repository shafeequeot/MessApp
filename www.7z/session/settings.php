<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>MessApp</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/normalize.min.css">
 <script src='../js/jquery-3.2.0.min.js'></script>
<script src="../js/jquery-ui-1.10.3.custom.min.js"></script>
    <script src="../js/index.js"></script>
  
      <link rel="stylesheet" href="../css/style.css">

  
</head>

<body>
  <div class="mobile">
	<div class="mainContainer">
		<header>
            <a href='../'><i href="../" class="left"></i> </a>
           <a href="settings.php" class="logo">MessApp</a> 
			
		</header>
		<div class="container">
            <center>
                <div class="login">
     
    
     <?php
include("../connect.php");
require '../core.php';
include("../SessionLogged.php");
                    
if (loggedin())
{
    header('location: requestsent.php');
}  

                    
if (isset($_COOKIE['CustID']) && !empty($_COOKIE['CustID']))
{
   $CustID = $_COOKIE['CustID'];
  include("../room.php");


if ($Room == 0 )
{
header('location: Selectmethod.php');   
}
}



if (isset($_COOKIE['CustID']) && !empty($_COOKIE['CustID']))
{
   $CustID = $_COOKIE['CustID'];
   $Room = $_COOKIE['Room'];


if ($Room == 0 )
{
header('location: Selectmethod.php');
}
else
{
// header('location: ../session/');
}}else
            {
              header('location: ../index.php'); 
            }            
                    

                    
if (isset($_POST['BtnCancel']))

{
    
    
    header('location: ../session');
    
    
}
                    
                    
if (isset($_POST['btn']))
{
    
    }
                    
  ?>
   
                    <div class='login'>
                        <h1>I am</h1>
                        <input type="radio" name="vecate" value="1"><span class="sgreen">Going to vecation</span>
                        <input type="radio" name="vecate" value="Vecate this room"> <span class="sgreen">room vecate</span><br><br>
                        <input type="button" class ='btn btn-def btn-block' value="Save" name="RoomVecate" id="RoomVecate">
                    </div><br>
                    
                    
               
<?php                         
       echo "<div class='login'> <h1>Edit Room Detials</h1><form method='post'>
       
         
        <span class='sgreen'> Room Name </span> <br>
        <input type='text' name = 'Name' id='Name' value= 'aaa' require><br>
            
                <span class='sgreen'> Month Starting on </span><br>
                <div id='frmCheckUsername'>
                <input type='text' name = 'UserName'id='UserName' value= 'aaa' onBlur='checkAvailability()' require><br><span id='user-availability-status'></span></div>
                <br>
             <span class='sgreen'> Change Currency </span> <br>
             <input type='text' name = 'Password' id='Password' value= 'aaa' onfocusout='PwordChanged()' require><br><br>
             
            <input type='button' class ='btn btn-def btn-block' value='Save' name='RoomVecate' id='RoomVecate'>";

 
?>

                    
                
 

</div></center>
         
		

            
            
<script type="text/javascript">
 
    
//    
//function checkAvailability() {
//	$("#loaderIcon").show();
//	jQuery.ajax({
//	url: "check_availability.php",
//	data:'username='+$("#UserName").val(),
//	type: "POST",
//	success:function(data){
//		$("#user-availability-status").html(data);
//		$("#loaderIcon").hide();
//	},
//	error:function (){}
//	});
//}
//    
</script>




		<footer>
            
		</footer>
	</div>
</div>
 

</body> 
</html>
